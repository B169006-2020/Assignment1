#this is my better script
#done using different approaches
#this script is not going work
#this script is not good
